package com.bbagliotto.reto10.reto10;

public class Empresa {

    private String razon_social, nit_rep_legal, ciudad, representante, direccion, telefono;


    public String getRepresentante() {
        return representante;
    }

    public void setRepresentante(String representante) {
        this.representante = representante;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getRazon_social() {
        return razon_social;
    }

    public void setRazon_social(String razon_social) {
        this.razon_social = razon_social;
    }

    public String getNit_rep_legal() {
        return nit_rep_legal;
    }

    public void setNit_rep_legal(String nit_rep_legal) {
        this.nit_rep_legal = nit_rep_legal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    @Override
    public String toString() {
        return "Club{" +
                "nombre='" + razon_social + '\'' +
                '}';
    }
}
