package com.bbagliotto.reto10.reto10;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.MyViewHolder> implements Filterable {

    private ArrayList<Empresa> empresas, empresasfiltradas;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextViewRazon, mTextViewCiudad, mTextViewPhone, mTextViewAdress, mTextViewRepresentante;

        public MyViewHolder(View v) {
            super(v);
            mTextViewRazon = (TextView) v.findViewById(R.id.razon_text_view);
            mTextViewCiudad = (TextView) v.findViewById(R.id.ciudad_text_view);
            mTextViewPhone = (TextView) v.findViewById(R.id.phone_text_view);
            mTextViewAdress = (TextView) v.findViewById(R.id.adress_text_view);
            mTextViewRepresentante = (TextView) v.findViewById(R.id.responsible_text_view);
        }
    }

    public Adaptador(ArrayList<Empresa> empresas) {
        this.empresas = empresas;
        this.empresasfiltradas = empresas;
    }

    @NonNull
    @Override
    public Adaptador.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.text_view, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        final Empresa empresa = empresasfiltradas.get(i);
        myViewHolder.mTextViewRazon.setText(empresa.getRazon_social());
        myViewHolder.mTextViewCiudad.setText(empresa.getCiudad());
        myViewHolder.mTextViewPhone.setText(empresa.getTelefono());
        myViewHolder.mTextViewAdress.setText(empresa.getDireccion());
        myViewHolder.mTextViewRepresentante.setText(empresa.getRepresentante());
    }

    @Override
    public int getItemCount() {
        return empresasfiltradas.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    empresasfiltradas = empresas;
                } else {
                    ArrayList<Empresa> filteredList = new ArrayList<>();
                    for (Empresa c : empresas) {
                        if (c.getDireccion().toLowerCase().contains(charString.toLowerCase())
                                || c.getCiudad().toLowerCase().contains(charSequence)
                                || c.getRazon_social().toLowerCase().contains(charSequence)
                                || c.getTelefono().toLowerCase().contains(charSequence)
                                || c.getRepresentante().toLowerCase().contains(charSequence)) {
                            filteredList.add(c);
                        }
                    }
                    empresasfiltradas = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = empresasfiltradas;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                empresasfiltradas = (ArrayList<Empresa>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }
}
